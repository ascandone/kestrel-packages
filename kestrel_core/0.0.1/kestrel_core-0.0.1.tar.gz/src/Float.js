function Float$from_int(n) {
  return n;
}

const Float$ceil = Math.ceil;

const Float$floor = Math.floor;
