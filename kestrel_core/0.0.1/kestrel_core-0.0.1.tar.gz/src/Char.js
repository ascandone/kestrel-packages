function Char$from_code(code) {
  return String.fromCharCode(code);
}

function Char$to_code(ch) {
  return ch.charCodeAt(0);
}
