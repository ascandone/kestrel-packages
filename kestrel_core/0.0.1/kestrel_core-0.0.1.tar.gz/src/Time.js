const Time$now = new Task$Task((resolve) => {
  resolve(Date.now());
});
